import boto3

def lambda_handler(event, context):
    ec2 = boto3.client('ec2')
    asg_name = event['detail']['AutoScalingGroupName']
    instance_id = event['detail']['EC2InstanceId']
    
    instance_name = f"{asg_name}-{instance_id[-6:]}"  # Example naming convention
    ec2.create_tags(Resources=[instance_id], Tags=[{'Key': 'Name', 'Value': instance_name}])
    
    return {
        'statusCode': 200,
        'body': f'Instance {instance_id} named {instance_name}'
    }
